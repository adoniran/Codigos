/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maib;

import Entitys.Arquivo;
import Entitys.Autor;
import Entitys.Editora;
import Entitys.Livro;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 *
 * @author Adoniran P. dos Reis Damasio
 */
public class Tetse {
     public static void main(String[] args) {
         Livro livro= new Livro();
         Autor autor = new Autor();
         Editora ed = new Editora();
         Arquivo arq = new Arquivo();
         EntityManagerFactory emf = Persistence.createEntityManagerFactory("Exercicio_SoftwareCorpPU");
         
         
         livro.setIbsn("jdsaçofds");
         livro.setTitulo("perry o Jackson e o gato de energia");
         autor.setCpf("8794626654");
         autor.setPrimeiroNome("Scott");
         autor.setUltimoNome("MCall");
         livro.adicionar(autor);
         
         ed.setNome("Saraiva");
         arq.setNome("arquivo nome");
         arq.setExtensao("EPUB");
         livro.setArquivo(arq);
//         ed.adicionar(livro);
         livro.setEditora(ed);
         Long i =persisir(emf,livro);
         
         System.out.println("return id Persistence:"+i); 
         System.gc(); 
         System.out.println("return:"+consultar(emf,i)); 

         
         
          
     
     
     }
     
     public static Long persisir(EntityManagerFactory emf, Livro Livro){
         
         
         
        
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();//            
        tx.begin();
        em.persist(Livro);
        tx.commit();em.close();emf=null;
     
     return Livro.getId();
     }
     
     public static String consultar(EntityManagerFactory emf, long idLivro){
         
        
        EntityManager em = emf.createEntityManager();
         EntityTransaction tx = em.getTransaction();//            
        tx.begin();
        Livro livro = em.find(Livro.class,idLivro );
        tx.commit();em.close();
        
        return livro.toString();   
     
     
     }
}
